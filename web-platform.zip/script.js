
document.getElementById('formulario-inscripcion').addEventListener('submit', function(e) {
  e.preventDefault();
  
  // Recoger datos del formulario
  const nombre = document.getElementById('nombre').value;
  const email = document.getElementById('email').value;
  const discapacidad = document.getElementById('discapacidad').value;
  const descripcion = document.getElementById('descripcion').value;
  
  // Validar campos requeridos
  if (!nombre || !email || !discapacidad) {
      alert('Por favor complete todos los campos requeridos');
      return;
  }
  
  // Simular envío de datos
  console.log('Datos enviados:', { nombre, email, discapacidad, descripcion });
  
  // Mostrar mensaje de éxito
  alert('¡Inscripción completada! Nos pondremos en contacto pronto.');
  
  // Resetear formulario
  this.reset();
});

// Scroll suave para navegación
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
          window.scrollTo({
              top: targetElement.offsetTop - 70,
              behavior: 'smooth'
          });
      }
  });
});